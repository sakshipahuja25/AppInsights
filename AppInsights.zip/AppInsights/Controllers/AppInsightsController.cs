using Microsoft.AspNetCore.Mvc;

namespace AppInsights.Controllers;
using AppInsights.Models;

[ApiController]
[Route("[controller]")]
public class AppInsightsController : ControllerBase
{
    

    private readonly AppInsightsContext _DbContext;
    public AppInsightsController(AppInsightsContext _DbContext)
    {
        this._DbContext=_DbContext;
    }

    [HttpGet("GetAll")]
    public IActionResult GetAll()
    {
        var AppInsights=this._DbContext.AppInsightData.ToList();
        return Ok(AppInsights);
    }
}
