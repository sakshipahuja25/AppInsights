﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace AppInsights.Models;

public partial class AppInsightsContext : DbContext
{
    public AppInsightsContext()
    {
    }

    public AppInsightsContext(DbContextOptions<AppInsightsContext> options)
        : base(options)
    {
    }

    public virtual DbSet<AppInsightDatum> AppInsightData { get; set; }

    public virtual DbSet<AppInsightSubscription> AppInsightSubscriptions { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=ADV-DEV-SQL;Database=AppInsights;User id=Sakshi.Pahuja;Password=pass@word1; TrustServerCertificate=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<AppInsightDatum>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__AppInsig__3213E83FB7CC283C");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.ApplicationId).HasColumnName("Application_id");
            entity.Property(e => e.ApplicationName)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.BrowserName)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.CreatedAt)
                .IsRowVersion()
                .IsConcurrencyToken()
                .HasColumnName("Created_At");
            entity.Property(e => e.DeviceType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.LocationX)
                .HasColumnType("decimal(7, 5)")
                .HasColumnName("Location_X");
            entity.Property(e => e.LocationY)
                .HasColumnType("decimal(7, 5)")
                .HasColumnName("Location_Y");
            entity.Property(e => e.ModuleName)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.SessionIdentifier)
                .HasMaxLength(40)
                .IsUnicode(false);
            entity.Property(e => e.UserName)
                .HasMaxLength(20)
                .IsUnicode(false);

            entity.HasOne(d => d.Application).WithMany(p => p.AppInsightData)
                .HasForeignKey(d => d.ApplicationId)
                .HasConstraintName("FK__AppInsigh__Appli__31EC6D26");
        });

        modelBuilder.Entity<AppInsightSubscription>(entity =>
        {
            entity.HasKey(e => e.ApplicationId).HasName("PK__AppInsig__E064DD93F039377C");

            entity.ToTable("AppInsightSubscription");

            entity.Property(e => e.ApplicationId)
                .ValueGeneratedNever()
                .HasColumnName("Application_id");
            entity.Property(e => e.ApplicationName)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.OrganisationName)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.SecurityKey)
                .HasMaxLength(15)
                .IsUnicode(false)
                .HasColumnName("Security_key");
            entity.Property(e => e.SubscriptionExpires)
                .HasColumnType("datetime")
                .HasColumnName("Subscription_expires");
            entity.Property(e => e.SubscriptionStarts)
                .IsRowVersion()
                .IsConcurrencyToken()
                .HasColumnName("Subscription_starts");
            entity.Property(e => e.SubscriptionType).HasColumnName("Subscription_type");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
