﻿using System;
using System.Collections.Generic;

namespace AppInsights.Models;

public partial class AppInsightDatum
{
    public long Id { get; set; }

    public byte[] CreatedAt { get; set; } = null!;

    public int? ApplicationId { get; set; }

    public string ApplicationName { get; set; } = null!;

    public string ModuleName { get; set; } = null!;

    public string UserName { get; set; } = null!;

    public int? PageNumber { get; set; }

    public decimal? LocationX { get; set; }

    public decimal? LocationY { get; set; }

    public string? BrowserName { get; set; }

    public int? LoadTime { get; set; }

    public string? SessionIdentifier { get; set; }

    public string? DeviceType { get; set; }

    public int? NetworkUsage { get; set; }

    public virtual AppInsightSubscription? Application { get; set; }
}
