﻿using System;
using System.Collections.Generic;

namespace AppInsights.Models;

public partial class AppInsightSubscription
{
    public int ApplicationId { get; set; }

    public string ApplicationName { get; set; } = null!;

    public string OrganisationName { get; set; } = null!;

    public string SecurityKey { get; set; } = null!;

    public byte[] SubscriptionStarts { get; set; } = null!;

    public DateTime SubscriptionExpires { get; set; }

    public long SubscriptionType { get; set; }

    public virtual ICollection<AppInsightDatum> AppInsightData { get; } = new List<AppInsightDatum>();
}
